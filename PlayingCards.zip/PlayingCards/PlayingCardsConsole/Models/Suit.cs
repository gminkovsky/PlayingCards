﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayingCards.Models
{
    public enum Suit
    {
         Club = 1,  
        Diamond = 2, 
        Heart = 3, 
        Spades = 4  
    }
}
