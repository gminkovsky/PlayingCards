﻿using PlayingCards.Interfaces;
using PlayingCards.Models; 

   
        IDeck newDeck = new Deck();
        newDeck.PrintCards();
        System.Console.WriteLine("");

        newDeck.Shuffle();
        newDeck.PrintCards();
        System.Console.WriteLine("");

        newDeck.Shuffle();
        newDeck.PrintCards();
        System.Console.ReadLine();
     
 
